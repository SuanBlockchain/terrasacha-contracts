# Types API Reference

API reference documentation for type definitions.

## Coming Soon

Detailed API documentation for:
- DatumProtocol
- Redeemer types
- Type aliases
- Constants

For now, see:
- [Types & Datums](../architecture/types.md)
- [Source Code](https://github.com/SuanBlockchain/terrasacha-contracts/blob/main/src/terrasacha_contracts/types.py)
