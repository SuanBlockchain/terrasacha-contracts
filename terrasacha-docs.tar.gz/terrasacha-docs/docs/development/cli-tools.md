# CLI Tools

Command-line tools and utilities for Terrasacha Contracts development.

## Coming Soon

Documentation for:
- Interactive CLI menu
- Build tools
- Deployment scripts
- Utility commands

For now, see:
- [Build System](build-system.md)
- [Development Guide](../getting-started/development.md)
